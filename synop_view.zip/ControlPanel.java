import java.awt.*;
import java.beans.*;
import com.sun.java.swing.*;

public class ControlPanel extends java.awt.Panel  
{
	// control interface
	ControlSystem controlSystem;

	//{{DECLARE_CONTROLS
	java.awt.Panel buttonPanel = new java.awt.Panel();
	java.awt.Button zoomInButton = new java.awt.Button();
	java.awt.Button baseViewButton = new java.awt.Button();
	java.awt.Button zoomOutButton = new java.awt.Button();
	java.awt.Button priviousButton = new java.awt.Button();
	java.awt.Button selectButton = new java.awt.Button();
	java.awt.Button centerButton = new java.awt.Button();
	java.awt.Panel textPanel = new java.awt.Panel();
	java.awt.TextField textAreaLabel = new java.awt.TextField();
	java.awt.TextArea textArea = new java.awt.TextArea(1,0);
	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == priviousButton)
				priviousButton_ActionPerformed(event);
			else if (object == baseViewButton)
				baseViewButton_ActionPerformed(event);
			else if (object == zoomOutButton)
				zoomOutButton_ActionPerformed(event);
			else if (object == zoomInButton)
				zoomInButton_ActionPerformed(event);
			else if (object == selectButton)
				selectButton_ActionPerformed(event);
			if (object == centerButton)
				centerButton_ActionPerformed(event);
		}
	}

	public ControlPanel()
	{

		//{{INIT_CONTROLS
		setLayout(new BorderLayout(0,0));
		Insets ins = getInsets();
		setSize(200,500);
		buttonPanel.setLayout(null);
		add("North",buttonPanel);
		buttonPanel.setBackground(java.awt.Color.lightGray);
		buttonPanel.setBounds(0,0,200,156);
		zoomInButton.setLabel("zoom In");
		buttonPanel.add(zoomInButton);
		zoomInButton.setBounds(6,0,186,24);
		baseViewButton.setLabel("base View");
		buttonPanel.add(baseViewButton);
		baseViewButton.setBounds(6,51,186,24);
		zoomOutButton.setLabel("zoom Out");
		buttonPanel.add(zoomOutButton);
		zoomOutButton.setBounds(6,24,186,24);
		priviousButton.setLabel("previous view");
		buttonPanel.add(priviousButton);
		priviousButton.setBounds(6,78,186,24);
		selectButton.setLabel("select");
		buttonPanel.add(selectButton);
		selectButton.setBounds(6,129,186,24);
		centerButton.setLabel("center last clicked device");
		buttonPanel.add(centerButton);
		centerButton.setBounds(6,102,186,24);
		centerButton.setVisible(false);
		textPanel.setLayout(null);
		add("Center",textPanel);
		textPanel.setBackground(java.awt.Color.lightGray);
		textPanel.setBounds(0,156,200,344);
		textAreaLabel.setEditable(false);
		textPanel.add(textAreaLabel);
		textAreaLabel.setBackground(java.awt.Color.white);
		textAreaLabel.setBounds(0,0,200,30);
		textArea.setEditable(false);
		textPanel.add(textArea);
		textArea.setBackground(java.awt.Color.white);
		textArea.setBounds(0,36,200,308);
		//}}

		//{{REGISTER_LISTENERS
		SymAction lSymAction = new SymAction();
		priviousButton.addActionListener(lSymAction);
		baseViewButton.addActionListener(lSymAction);
		zoomOutButton.addActionListener(lSymAction);
		zoomInButton.addActionListener(lSymAction);
		selectButton.addActionListener(lSymAction);
		centerButton.addActionListener(lSymAction);
		//}}
	}
	//}}

  public void appendTextArea(String str) {
   textArea.append(str);
  }  
	void baseViewButton_ActionPerformed(java.awt.event.ActionEvent event)
	{
		controlSystem.baseview();
	}
	void centerButton_ActionPerformed(java.awt.event.ActionEvent event)
	{
		controlSystem.centerDevice();
	}
	void priviousButton_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    controlSystem.previousView();
	}
	void selectButton_ActionPerformed(java.awt.event.ActionEvent event)
	{
		controlSystem.select();	
	}
  /*
  ** set the label of the center label to the last clicked device
  ** default is: "center last clicked device"
  */
  public void setCenterLabel (String s) {
	//centerButton.isVisible();
	centerButton.setVisible(true);
	centerButton.setLabel(s);
  }  
  public void setControlSystem(ControlSystem controlSystem) {
	this.controlSystem=controlSystem;
  }  
  public void setTextArea(String str) {
   textArea.setText(str);
  }  
  public void setTextAreaLabel(String str) {
   textAreaLabel.setText(str);
  }  
	void zoomInButton_ActionPerformed(java.awt.event.ActionEvent event)
	{
		controlSystem.zoomIn();	
	}
	void zoomOutButton_ActionPerformed(java.awt.event.ActionEvent event)
	{
		controlSystem.zoomOut();
	}
}
