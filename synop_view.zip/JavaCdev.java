/*
** Synoptic Viewer Java Cdev part to do all cdev Services...
** Marcel.Grunder@psi.ch
** aug.30.2000
*/
import java.util.StringTokenizer;
import cdev.data.*;
import cdev.*;

// gm02 new
import svp.devices.*;
import java.util.Hashtable;
import java.util.*;

public class JavaCdev {
  private cdev.ControlSystem sys;   // Cdev Gateway Server ControlSystem
  private boolean bStatus = false;  // Cdev Gateway connected
  // ControlSystem used to display results in the ControlPanel
  // (all ControlSystem methods are declared in ControlSystem.java and
  // are defined in SV.java)
  SVControlSystem sc;

  // to enable or disable debug infos... 
  int idebug = 0;       // default for the synoptic viewer
                        // 1 = Debug Info in the SV
  // to define the Mode Cdev gets the Results...
  // true = same as in cdevGet
  // false = sendNoBlock (Default)
  boolean bCdevMode = false;
  
  // interrest data
  Hashtable interrests = null;

  // gm02 new test... hierarchy hasthtable
  Hashtable hierarchy = null;

/*
** JavaCdev() constructor creates a connection to the ControlSystem
**
** parameter: ControlSystem = cs...
**            sHost = host to connect to the Gateway server 
**            port = port number of cdevGateway
**
*/
  public JavaCdev (SVControlSystem sc, String sHost, int iPort) {
	this.sc = sc;
	try {
	  sys   = cdev.ControlSystem.getDefault();
	  sys.connect(sHost, iPort);
	  bStatus = true;
	  if (idebug > 0)
	    sc.sc_setTextArea("Connected to " + sHost + " " + iPort + "...\n");
	} catch (Exception e) {
	  bStatus = false;      
	  if (idebug > 0)
	    sc.sc_setTextArea("NOT connected to " + sHost + " " + iPort + "...\n");
	}
  }

  /*
  ** to enable or disable debug infos...
  **
  ** 0  no debug information, just the results will be displayed
  ** 1  some debug info, used in the sls synoptic viewer...
  ** 2 	max debug information
  */
  public void setDebug(int status) {
    idebug = status;
  }

  /*
  ** showDeviceProperties()
  **
  ** parameter: sDevice		device name to get the properties and their results
  **
  ** in the synoptic viewer, this method is called when the user clicks on a device in the drawing
  ** or select it from the tree.
  ** the result are displayed in the ControlPanel. ControlSystem provides the interface to this class
  */
  public void sc_showDeviceProperties(String sDevice) {
    String[] saProperties = null;
    String sCommand = null;
    
    if (bStatus) {
	  // clip has connectet to host
	  // get the device properties...
	  //-----------------------------
	  sc.sc_setTextAreaLabel("Properties: " + sDevice);
      sc.sc_setTextArea("");  // clear TextArea...
	  // directoryService "queryAttributes" for the NEW style of SLS DDL files...
      saProperties = directoryService("queryAttributes", sDevice);
      if (saProperties == null) {
		if (idebug > 0)
		  sc.sc_appendTextArea("no properties found queryAttributes()\n");
	  	// directoryService "query" for the OLD style of SLS DDL files...
        saProperties = directoryService("query", (sDevice + ":"));
		if (saProperties == null) {
		  if (idebug > 0)
		    sc.sc_appendTextArea("no properties found query()\n");
		  else
		    sc.sc_setTextArea("no properties found for this device\n");
		  return;
		} else
		  // found old style defined device in the ddl file
		  sCommand = "query";
      } else {
        // found NEW style defined device in the ddl file
		sCommand = "queryAttributes";
	  }
	  
	  // device properties catched successfull...
	  //-----------------------------------------
	  int len = saProperties.length;
	  if (idebug > 0)
        sc.sc_appendTextArea(sCommand + " found " + len + " properties\n");
	  
	  // control print of properties
	  //----------------------------
	  if (idebug == 2) {
	    for (int i = 0; i < len; i++) {
	      System.out.println("[" + i + "] = " + saProperties[i]);	  
	    }
		System.out.println("\n");
	  }
	  
	  // use cdev sendNoBlock() to get the values...
	  //--------------------------------------------
	  if (idebug > 0)
	    sc.sc_appendTextArea("please wait...\n");
	  if (sCommand.equals("queryAttributes")) {
	    // get saResults with device.sendNoBlock("get property")
		// used for ABOMA-QF-1 (new SLS DDL file structure)
        //------------------------------------------------------	
		if (!bCdevMode)
		  sendNoBlock(sDevice, saProperties);
	    else
	      send(sDevice, saProperties);
    
	  } else {
	  	// sCommand = "query" 
		// try to get the VAL fields for this device (using the OLD style DDL)
		//--------------------------------------------------------------------
	
	  	// skip any properties containing "TMG-Evr"
	  	//-------------------------------------------
	  	int new_len = 0;
	  	int x = 0;
	  	String[] saTest = null;
	  	for (int i = 0; i < len; i++) {
		  if (saProperties[i].indexOf("TMG-Evr") < 0) {
		    // Evr not found in this property, so use it...
		    new_len++;
		  }
		}
		
		// if needed rebuild the properties array and the get the results of the properties
		//---------------------------------------------------------------------------------
		if (new_len < len) {
			// some properties contain "TMG-Evr", so create a new properties array and then
			// get the results of this properties
			saTest = new String[new_len];
			for (int i = 0; i < len; i++) {
			  if (saProperties[i].indexOf("TMG-Evr") < 0) {
			    // Evr not found in this property, so use it...
			    saTest[x] = saProperties[i];
			    x++;
			  } else {
			  	// display a warning in the ControlPanel
	  			sc.sc_appendTextArea(saProperties[i] + "\t= ... skiped!\n");		  
			  }
			}
			sendNoBlock(saTest);
		} else {
			// get the results for all properties...
			sendNoBlock(saProperties);
		}		
	  }  // end sCommand.equals....	  
	} else {
	  // Cdev is not connected... so clear the text areas...    
	  sc.sc_setTextArea("");
	  sc.sc_setTextAreaLabel("");
	} 
  }
  
  /*
  ** directoryService
  **
  ** parameter: sCommand	tested with "query" and "queryAttributes"
  **			sDevice		like "ALIVA-VG-5"
  ** return:	Sting[]		properties of the directoryService
  **						return something like "STATUS" or "I-READ"
  */
  public String[] directoryService (String sCommand, String sDevice) {
    try {
      cdev.Device dev       = new cdev.Device("cdevDirectory");
      cdev.data.Data data   = new cdev.data.Data();
      cdev.data.Data result = new cdev.data.Data();
	  cdev.DeviceError err  = null;
	  String[] saResult     = null;
      //data.insert("class", "*");
      data.insert("device", sDevice);

	  if (idebug == 2) {
	    System.out.println("dev.send (" +sCommand+", *, "+sDevice +")");
	  }
	  
	  // execute the directoryService()
      err = dev.send (sCommand, data, result);
      
	  if (err != null) {
        // error execute directoryService()
		return null;
      } else {
        saResult = result.getDataEntry("value").stringArray();
		int len     = saResult.length;		// len of the result array (includes properties with ".")
	    
		// when "queryAttributes" currently no properties with ".field" are used...
		//-------------------------------------------------------------------------
		if (sCommand.equals("queryAttributes")) {
		  // for queryDirectory: remove all properties that contain a "." in the result[]
		  int new_len = 0;						// new_len of the result array (without ".")
		  for (int i = 0; i < len; i++) {
			// first calculate the number of string elements that donot contain a "."
			if ((saResult[i].indexOf(".")) <= 0) {
			  // -1 = indexOf does not contain any "."
			  // so use a property
			  new_len++;
			}
		  }
		  // test if there is a difference between the original len and the new_len (properties without ".") 
		  if (new_len < len) {
		    // the new_len is smaller than the original one, 
			// so create a new String[], and store the properties in this one...
			String[] saNPProperties = new String[new_len];	// NoPoint Properties to return...
			int x = 0;									// index 
			
			if (idebug == 1)
			  System.out.println(sCommand + " found " + len + " properties (including ALL fields)");
			for(int i = 0; i < len; i++) {
			  if ((saResult[i].indexOf(".")) <= 0) {
			    // -1 = indexOf does not contain any "."
			  	saNPProperties[x] = saResult[i];
				x++;
			  } else {
			  	if (idebug == 2)
				  System.out.println ("INFO: property : " + saResult[i] + "\t... is not a VAL field");
			  }
			}
			// now return the saNPProperties (does not contain any Properties with ".")
			return saNPProperties;
		  }
		}
	    return saResult;
	  }
    } catch (Exception e) {
	  System.out.println("JavaCdev().directoryService exception: " + e);
	  return null;
    }
  }
    
  /*
  ** sendNoBlock(device, properties) is used with the NEW SLS DDL file structure
  **
  ** parameter:   sDevice 
  **			  properties = the string array of properties to send
  **			  example:  ...
  */
  public void sendNoBlock (String sDevice, String[] saProperties) {
	int len                    = saProperties.length;
	cdev.data.Data[] caResult;
	caResult                   = new cdev.data.Data[len];
	
	if (idebug > 0) {
	  sc.sc_appendTextArea("Info: this device use the \"new\" style cdev.ddl file format)\n");
    }
	
	try {
	  cdev.Device cDevice;
	  cDevice = sys.getDevice(sDevice);
		for (int i = 0; i < len; i++) {
	  	  caResult[i] = new cdev.data.Data();
		  cDevice.sendNoBlock("get " + saProperties[i], null, caResult[i]);
		}
	} catch (Exception e) {
	  // failed to sendNoBlock
      sc.sc_appendTextArea("failed Device.sendNoBlock()\n");	  
	}
	
	try {
	  sys.pend();
	} catch (Exception e) {
      sc.sc_appendTextArea("failed sys.pend()\n");	  
	}
	
	// convert and display the caResult[] 
	try {
	  convertResults (caResult, saProperties);
	} catch (Exception e) {
      sc.sc_appendTextArea("ERROR 1 convertResults... " + e + "\n");	  
	}
  } 

  /*
  ** sendNoBlock(properties) is used with the OLD SLS DDL file structure
  **
  ** parameter:   properties = the string array of properties to send
  **			  example: ALIVA-VG-5:STATUS ...
  */
  public void sendNoBlock (String[] saProperties) {
	int len             = saProperties.length;
	cdev.data.Data[]  caResult;
	caResult            = new cdev.data.Data[len];
	String[] sResults   = new String[len];

    if (idebug > 0) {
	  sc.sc_appendTextArea("Info: this device use the \"old\" style cdev.ddl file format)\n\n");
    }
	cdev.Device cDevices[] = new cdev.Device[len];
	for (int i = 0; i < len; i++) {
	  caResult[i] = new cdev.data.Data();
	  try {
		//cDevices[i] = new Device((properties[i]));  // both are working
		cDevices[i] = sys.getDevice(saProperties[i]);
		cDevices[i].sendNoBlock("get VAL", null, caResult[i]);
	  } catch (Exception e) {
		// failed to sendNoBlock
        sc.sc_appendTextArea("failed Device.sendNoBlock()\n");	  
	  }
	}
	try {
	  sys.pend();
	} catch (Exception e) {
      sc.sc_appendTextArea("failed sys.pend()\n");	  
	}
	
	// convert and display the caResult[] 
	try {
	  convertResults (caResult, saProperties);
	} catch (Exception e) {
      sc.sc_appendTextArea("ERROR 2 convertResults... " + e + "\n");	  
	}
  } 

  public void convertResults (cdev.data.Data[] acResult, String[] saProperties) {
	try {
 	  int len = acResult.length;
	  cdev.data.DataEntry de;
	
    if (idebug == 0) {
      // no debug infos...
	  for (int i=0; i<len; i++) {
		de = acResult[i].getDataEntry("value");
		if (de == null)
		  sc.sc_appendTextArea(saProperties[i] + " = \tnull\n");		
		else
		  sc.sc_appendTextArea(saProperties[i] + " = \t" + dataString((DataEntry)de) + "\n");		
	  }
    }
    else {
      // some debug infos...
	  for (int i=0; i<len; i++) {
		de = acResult[i].getDataEntry("value");
		if (de == null)
		  sc.sc_appendTextArea("[" + i + "] " + saProperties[i] + " = \tnull\n");		
		else
		  sc.sc_appendTextArea("[" + i + "] " + saProperties[i] + " = \t" + dataString((DataEntry)de) + "\n");		
	  }
    }

	} catch (Exception e) {
	  sc.sc_appendTextArea("Fehler in convertResults " + e + "\n");	  
    }
  } 

  /*
  ** convertResult() to convert the Result only from cdevGet()
  **
  */
  public void convertResult (cdev.data.Data cResult, String saProperty) {
	try {
	  cdev.data.DataEntry de;
	
	  de = cResult.getDataEntry("value");
	  if (de == null)
		sc.sc_appendTextArea(saProperty + " = \tnull\n");		
	  else
		sc.sc_appendTextArea(saProperty + " = \t" + dataString((DataEntry)de) + "\n");		
	} catch (Exception e) {
	  sc.sc_appendTextArea("Error in convertResults " + e + "\n");	  
    }
  } 


 public String dataString(DataEntry data) {
  switch (data.getEnumeratedType()) {
	case Data.INT   : 
    	if (idebug < 2)
			return String.valueOf(data.intValue());
        else
			return String.valueOf(data.intValue() + "\t(INT)");
	case Data.LONG :
    	if (idebug < 2)
			return String.valueOf(data.longValue());
        else
            return String.valueOf(data.longValue() + "\t(LONG)");
	case Data.SHORT :
    	if (idebug < 2)
			return String.valueOf(data.shortValue());
        else
			return String.valueOf(data.shortValue() + "\t(SHORT)");
	case Data.FLOAT :
    	if (idebug < 2)
			return String.valueOf(data.floatValue());
        else
			return String.valueOf(data.floatValue() + "\t(FLOAT)");
	case Data.DOUBLE :
    	if (idebug < 2)
			return String.valueOf(data.doubleValue());
        else
			return String.valueOf(data.doubleValue() + "\t(DOUBLE)");
	case Data.BYTE :
    	if (idebug < 2)
			return String.valueOf(data.byteValue());
        else
            return String.valueOf(data.byteValue() + "\t(BYTE)");
	case Data.STRING :
    	if (idebug < 2)
			return String.valueOf(data.stringValue());
        else
			return String.valueOf(data.stringValue() + "\t(STRING)");
	default    : return "???";
  }
}

 /**
  * isConnected() returns the the connection status
  *
  * return: true  = connected to the cdevGatewayServer
  *         false = not conneted
  *
  * note; set also flag bStatus to true or false...
  *
  **/
  public boolean isConnected () {
	try {
	  bStatus = sys.isConnected();
	  return bStatus;
	} catch (Exception e) {
	  bStatus = false;
	  return false;
	}
  }

 /**
  * getStatus() returns the the connection status indicated 
  * by flag bStatus
  *
  * return: true  = connected to the cdevGatewayServer
  *         false = not conneted
  *
  *
  **/
  public boolean getStatus () {
	  return bStatus;
  }


 /**
  ** disconnect()
  **
  **/
  public void disconnect () {
	try {
	  sys.disconnect();
	  if (idebug > 0)
	    sc.sc_setTextArea("CDev is now disconnected...\n Reconnect again to get any results...\n");
	  bStatus = false;
	} catch (Exception e) {
	}
  }

  /*
  ** reconnectCdev() if the connection is broken, reconnect to cdevGateway
  **
  */
  public void sc_reconnectCdev () {
	try {
	  sys.reconnect();
	  if (idebug > 0)
	    sc.sc_setTextArea("Cdev reconnect...\n");
	  bStatus = true;
	} catch (Exception e) {
	    sc.sc_setTextArea("Cdev reconnect failed...\n");
	  bStatus = false;      
	}
  }

  /**
   *
   *
   */
  public boolean readInterrestFile(String fileName) {
	if (hierarchy==null) {
	  interrests = svp.parser.SVParser.parseInterrests(fileName);
	  if (interrests==null) return false;

	  try {
	    //System.out.println("elements = " + interrests.elements());
        InterrestsData id;
	    Enumeration e = interrests.elements();
	    while (e.hasMoreElements()) {
          id = (InterrestsData) (e.nextElement()); 
	      ///System.out.println("addChoice: " + id.getName());
	      sc.sc_addInterrestChoice(id.getName());
	      //sc.sc_addInterrestChoice(id.getName());
	    }
	  } catch (Exception e) {
	    System.out.println("Error: JavaCdev readInterrestFile() addInterrestChoice..." + e);
	  }
	  return true;
	} else {
	  System.out.println("javaCdev readInterrestFile = null");
	  return false;
    }
  }

  /*
  ** send    will call cdevGet for each element in the saProperties
  **
  ** parameter:   properties = the string array of properties to send
  **			  example: ALIVA-VG-5:STATUS ...
  */
  public void send (String sDevice, String[] saProperties) {
	int len = saProperties.length;

    if (idebug > 0) {
	  sc.sc_appendTextArea("Info: cdevGet called " + len + " times\n\n");
    }
	for (int i = 0; i < len; i++) {
      cdevGet(sDevice + ":" +saProperties[i]);
    }
  } 

  /*
  ** cdevGet() does a "normal" cdevGet for one device
  **
  ** parameter:    device = the device to pass to getCdev (like "hunt:ai001")
  ** return:       String of cdevGet or null when failed
  */
  public void cdevGet (String device) {
	String sChannel = null;  // CDEV device name
	String sField   = null;  // EPICS filed name
	String sResult = null;

	StringTokenizer st = new StringTokenizer(device,".",false);
	sChannel = st.nextToken();

	System.out.println("cdevGET () " + device);

	try {
	 sField = st.nextToken();
	} catch (Exception e) {
	  sField = "VAL";
	}

	try {
	  cdev.data.Data cResult = new cdev.data.Data();
	  cdev.Device    myDev   = new cdev.Device(sChannel);

      // do the cdev call..
	  myDev.get(sField, cResult);
	  
	  // convert the result to string result sResult

      // show ALIVA-VG-5:I-SET
      //convertResult (cResult, device);
      // show only I-SET
      convertResult (cResult, device.substring((device.indexOf(":")+1)) );

	} catch (Exception e) {
	  // failed cdevGet
      sc.sc_appendTextArea("failed cdevGet() " + device + "\n");	  
	}
	return;
  }  

  public void setCdevMode(boolean b) {
    bCdevMode = b;
  }
//====================================================


  public void setInterrestGroup(String str) {
    System.out.println("cdevSystem: InterrestGroup = " + str);  
    System.out.println (str + " = " + interrests.get(str));
    
    InterrestsData id = (InterrestsData)(interrests.get(str));;
	Enumeration e = id.getTable().elements();
	while (e.hasMoreElements()) {
      id = (InterrestsData) (e.nextElement()); 
      System.out.println(str + ", Property: " + id.getParentName());
	}

//	Enumeration e = interrests.elements();
//	while (e.hasMoreElements()) {
//      id = (InterrestsData) (e.nextElement()); 
//      System.out.println(str + ", Property: " + id.getParentName());
//	}

  }

}