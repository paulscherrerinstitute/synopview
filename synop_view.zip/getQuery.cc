#include <cdevSystem.h>
#include <cdevDevice.h>
#include <cdevService.h>
#include <cdevRequestObject.h>

#include <jni.h>
#include "JniCdev.h"			// the include file created by javah -jni classfilename
#include <stdio.h>

static size_t getLength (cdevData& data) {
  size_t len, dim;
  data.getDim ("value", &dim);
  if (dim != 0) {
    cdevBounds bounds;
    data.getBounds ("value", &bounds, 1);
    len = bounds.length;
  } else
    len = 1;
  return len;
}

// function header from file JniCdev.h, added only the parameters name and
// remouved the ';' and added the '{' and added the passed variable names
// old... JNIEXPORT jobjectArray JNICALL Java_JniCdev_query
//  (JNIEnv *env, jobject obj, jstring jsDevice) {
JNIEXPORT jobjectArray JNICALL Java_JniCdev_query
  (JNIEnv *env, jobject obj, jstring jsCommand, jstring jsDevice) {

  const char *sDevice  = env->GetStringUTFChars(jsDevice, 0);
  const char *sCommand = env->GetStringUTFChars(jsCommand, 0);
  
  jobjectArray RetArray;
  jobject      StringObj;
  jclass       StringClass;
  int          x; 
  int          dim=6;
  char         aStr[80];
  
  cdevSystem& system = cdevSystem::defaultSystem ();  
  cdevDevice& directory = cdevDevice::attachRef ("cdevDirectory");

  cdevData out;
  cdevData result;
  
  out.remove ();
  result.remove ();
  out.insert ("device", (char *)sDevice);
  out.insert ("class", "*");

  // printf (query (%s, %s", sCommand, out);
  if (directory.send ((char*) sCommand, out, result) == CDEV_SUCCESS) {
    size_t len = getLength (result);
    char **verbs;
    verbs = new char* [len];
    StringClass = env->FindClass("java/lang/String");
    RetArray = env->NewObjectArray(len, StringClass, NULL);
 
    result.get ("value", verbs);
    for (int i = 0; i < len; i++) {
      StringObj = env->NewStringUTF(verbs[i]);
      env->SetObjectArrayElement(RetArray, i, StringObj);
      delete []verbs[i];
    }
    delete []verbs;
  }  else {
    // printf ("Cannot find any matches for %s device\n", sDevice);
    env->ReleaseStringUTFChars(jsCommand, (const char *) sCommand); 
    env->ReleaseStringUTFChars(jsDevice, (const char *) sDevice); 
    return (0);
  }
  env->ReleaseStringUTFChars(jsCommand, (const char *) sCommand); 
  env->ReleaseStringUTFChars(jsDevice, (const char *) sDevice); 
  return (RetArray);
}
