import java.lang.String;

public class JniCdev {

  public JniCdev () {}  
  /* 
  ** try to get the device properties from the selected device...
  ** query * device      -> if result valied 
  **                          (like ALIVA-VG-5-:8SET...) return it
  **                        else
  ** queryAttributes     -> if result valied
  **                          (like I-SET) append results to device
  **                          (like ALIMA-O-15:I-SET) and retrun it
  **                        else
  **                          return null
  */         
  public static String[] getProperties (String device) {
    // return old fashion way "DEVICE.PROPERTIES"
	  
	String[] properties = null;
	try {
		// note when query a device, I get back the davicename:properties and
		// the device itselfe.
		// To avoit returning the device name: add ":" to the devicename
	  properties = new JniCdev().query("query", (device + ":"));
	} catch (java.lang.UnsatisfiedLinkError s) {
	  // this error should not occur, even if the device is not defined in the ddl file
	  System.out.println("ERROR:   try to JniCdev().query(query, " + device + ")");
	  return null;
	}

	if (properties != null) {
	  System.out.println("query " + (device + ":") + ", len = " + properties.length);
	  // return the found properties for this device
	  return properties;
	} else {
	  // System.out.println("query, no properties for device " + device);
  	  // no "query" match found for this device...
	  // if the properties in the ddl files are defined as "alias" then
	  // "queryAttributes" get the results
	  /* directoryTest.cc
	  queryAttributes
	  Enter class device pair
	  * ALIMA-OL-AS08
	  Attributes for class * device ALIMA-OL-AS08 are:
	  OVP
	  I-SET
	  ONOFF
	  I-COMP
	  I-READ 
	  */	
	  try {
		properties = new JniCdev().query("queryAttributes", device);
	  } catch (java.lang.UnsatisfiedLinkError s) {
		// this error should not occur, even if the device is not defined in the ddl file
		System.out.println("ERROR:   try to JniCdev().query(queryAttributes, " + device + ")");
		return null;
	  }

	  if (properties == null) {		
		// did not find any properties either with "query" or "queryAttibutes" 
		return null;  // waring in the calling method...
	  }
	  // found properties with queryAttributes!
	  // System.out.println("queryAttributes " + device + ", len = " + properties.length);
	  int len = properties.length;
	  int new_len = 0;
      // search for the "." and supress the in this release...
	  for (int i=0; i<len; i++) {
	    if ((properties[i].indexOf(".")) <= 0) {
	        // -1 = String "." not found... so use it as property
	        new_len ++;
        }	        
	  }
	  // if the len of the properties containing not "." is smallet than the original len,
	  // then reconstruct the property Array saP[],
	  // do as usual...
	  if (new_len < len) {
	    String[] asP = null;
	    asP = new String[new_len];
	    int new_index = 0;
	    for (int i=0; i<len; i++) {
	      if ((properties[i].indexOf(".")) <= 0) {
	        // no "." found...
	        asP[new_index] = device + ":" + properties[i];
	        new_index++;
	      }
	    }
        // return the found properties for this device
	    System.out.println("queryAttributes " + device + " found " + new_len + " properties out of " + len);
	    return asP;
	  } else { 
	    for (int i=0; i<len; i++) {
	      // property is only (for example I-SET), need to add devicename + ":"
	      properties[i] = device + ":" + properties[i]; 
	      // System.out.println("["+i+"] = " + properties[i]);
	    }
        // return the found properties for this device
	    System.out.println("queryAttributes " + device + " found " + len + " properties");
	    return properties;
	  }
	}
	//return properties;
  }

  public static String[] queryAttributes (String device) {
    // return only Strng[] "PROPERTIES" , currently without "."
	// first "queryAttributes"  then "query"  
	String[] properties = null;
	try {
		properties = new JniCdev().query("queryAttributes", device);
	} catch (java.lang.UnsatisfiedLinkError s) {
		// this error should not occur, even if the device is not defined in the ddl file
		System.out.println("ERROR:   try to JniCdev().queryAttributes (queryAttributes, " + device + ")");
		return null;
	}

	if (properties == null) {		
	  // no properties found "queryAttributes"-------------------
  	  try {
	    properties = new JniCdev().query("query", (device + ":"));
	  } catch (java.lang.UnsatisfiedLinkError s) {
	    // this error should not occur, even if the device is not defined in the ddl file
	    System.out.println("ERROR:   try to JniCdev().query(queryAttributes, " + device + ")");
	    return null;
	  }
	  if (properties != null) {
	    System.out.println("Warning: this device query is defined in the old style, so not supported in Synoptic Viewer..."); 
	    System.out.println("query " + (device + ":") + ", len = " + properties.length);
	    // return the found properties for this device without the deviceName
	    for (int i = 0; i < properties.length; i++) {
	      properties[i] = properties[i].substring((properties[i].indexOf(":")+1));
	    }
	    return properties;
	  } else {
		// did not find any properties either with "query" or "queryAttibutes" 
		return null;  // waring in the calling method...
	  }
	  //-----------------------
	}
	// found properties with queryAttributes!
	// System.out.println("queryAttributes " + device + ", len = " + properties.length);
	int len = properties.length;
	int new_len = 0;
    // search for the "." and supress the in this release...
	for (int i=0; i<len; i++) {
	    if ((properties[i].indexOf(".")) <= 0) {
	        // -1 = String "." not found... so use it as property
	        new_len ++;
        }	        
	}
	// if the len of the properties containing not "." is smallet than the original len,
	// then reconstruct the property Array saP[],
	// do as usual...
	if (new_len < len) {
	    String[] asP = null;
	    asP = new String[new_len];
	    int new_index = 0;
	    for (int i=0; i<len; i++) {
	      if ((properties[i].indexOf(".")) <= 0) {
	        // no "." found...
	        asP[new_index] = properties[i];
	        new_index++;
	      }
	    }
        // return the found properties for this device
	    System.out.println("queryAttributes " + device + " found " + new_len + " properties out of " + len);
	    return asP;
	} else { 
	    for (int i=0; i<len; i++) {
	      // property is only (for example I-SET), need to add devicename + ":"
	      properties[i] = device + ":" + properties[i]; 
	      // System.out.println("["+i+"] = " + properties[i]);
	    }
        // return the found properties for this device
	    System.out.println("queryAttributes " + device + " found " + len + " properties");
	    return properties;
	}
  }
  
  
  
  public static boolean ldLibrary() {
	boolean status = false;
	try {
	  System.loadLibrary("getQuery");					// Load the Library
	} catch (UnsatisfiedLinkError s) {
	  return false;
	}
	return true;
  }  
  // Declare a Native Method to acces cdev directory service
  public native String[] query(String command, String st);  
}
