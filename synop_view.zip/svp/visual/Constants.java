package svp.visual;

import java.awt.Color;



/**

 * Insert the type's description here.

 * Creation date: (12/7/99 21:54:38)

 * @author: Matej Sekoranja

 */

public interface Constants {

	final static Color backgroundColor = Color.white;
	final static Color outlineColor = Color.black;

	final static Color defaultColor = Color.white;

}
