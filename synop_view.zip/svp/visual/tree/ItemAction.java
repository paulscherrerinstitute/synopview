package svp.visual.tree;

public abstract class ItemAction {

	///////////////////////////////////////////////////////////////

	// initalisation 



	public ItemAction()

	{

	}
/**

 * Insert the method's description here.

 * Creation date: (18/7/99 15:33:32)

 */

public abstract void execute();
/**

 * Insert the method's description here.

 * Creation date: (4/9/99 12:44:44)

 */

public abstract void executeDBLClick();
}
